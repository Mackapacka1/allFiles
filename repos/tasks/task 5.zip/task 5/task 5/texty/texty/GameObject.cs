﻿using System;

namespace AdventureGame
{

    public abstract class GameObject
    {
        protected int xPosition;

        protected int yPosition;

        public abstract void Draw();


    }
}





