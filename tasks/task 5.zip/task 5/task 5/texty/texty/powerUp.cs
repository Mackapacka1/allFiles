﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AdventureGame
{
    public class PowerUp : GameObject
    {
        public override void Draw()
        {
            Console.Write("?");
        }
    }
}
