﻿using System;
using System.Collections.Generic;
using System.Text;

namespace texty
{
    internal class Class1
    {
    }
}
