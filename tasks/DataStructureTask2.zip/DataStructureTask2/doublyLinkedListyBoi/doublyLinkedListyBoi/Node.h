#pragma once
struct Node
{
public:
	int data;

	Node* prev;
	Node* next;
};

