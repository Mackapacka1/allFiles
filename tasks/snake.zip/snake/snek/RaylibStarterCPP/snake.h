#pragma once

class Snake
{
public:
	
	Snake();
	static void Update(float dt);
	virtual void Draw();

};

